﻿// Decompiled with JetBrains decompiler
// Type: Mercurial_ProcessedByFody
// Assembly: Mercurial, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE55527C-E5C8-48E5-83A1-C6805BBF517B
// Assembly location: C:\Users\thele\Downloads\Mercurial-Grabber-master\Mercurial-Grabber-master\Mercurial\Mercurial.exe

internal class Mercurial_ProcessedByFody
{
  internal const string FodyVersion = "6.5.1.0";
  internal const string Costura = "5.3.0";
}
