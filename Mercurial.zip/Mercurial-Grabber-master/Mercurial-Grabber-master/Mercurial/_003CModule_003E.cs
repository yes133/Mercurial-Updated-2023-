﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: Mercurial, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CE55527C-E5C8-48E5-83A1-C6805BBF517B
// Assembly location: C:\Users\thele\Downloads\Mercurial-Grabber-master\Mercurial-Grabber-master\Mercurial\Mercurial.exe

using Costura;

internal class \u003CModule\u003E
{
  static \u003CModule\u003E() => AssemblyLoader.Attach();
}
